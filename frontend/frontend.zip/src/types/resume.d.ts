export interface Resume {
  id: number;
  title: string;
  uploadDate: string;
  score: number;
}
