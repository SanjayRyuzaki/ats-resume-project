import React from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import styled from "styled-components";
import { useAuth } from "@/hooks/useAuth";
import { useGoogleLogin } from "@react-oauth/google";

const Navbar: React.FC = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { user, login, logout } = useAuth();

  const handleGoogleLogin = useGoogleLogin({
  onSuccess: async (googleResponse) => {
    try {
      const googleToken = googleResponse.access_token;

      // Send token to your backend
      const res = await fetch("http://localhost:5000/api/auth/google", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ token: googleToken }),
      });

      const data = await res.json();

      if (!res.ok) {
        throw new Error(data.error || "Google login failed");
      }

      // Store your own JWT and user info
      localStorage.setItem("token", data.token);
      login(data.user); // useAuth context
      navigate("/dashboard");

    } catch (err) {
      alert("Login failed. Please try again.");
      console.error("Google Login Error:", err);
    }
  },
  onError: () => {
    alert("Google login popup closed or failed.");
  },
});

  const handleLogout = () => {
    logout();
    navigate("/"); // ✅ Redirect to landing page after logout
  };

  return (
    <Nav>
      <Logo to="/">ATS Score</Logo>

      <NavLinks>
        {user && (
          <StyledLink to="/dashboard" $active={location.pathname === "/dashboard"}>
            Dashboard
          </StyledLink>
        )}
      </NavLinks>

      {user ? (
        <ProfileSection>
          <Avatar
            src={user.avatarUrl || `https://ui-avatars.com/api/?name=${user.name}`}
            alt="Profile"
          />
          <UserName>{user.name}</UserName>
          <LogoutButton onClick={handleLogout}>Logout</LogoutButton>
        </ProfileSection>
      ) : (
        <NavLinks>
          <StyledNavButton onClick={() => handleGoogleLogin()}>
            Login
          </StyledNavButton>
        </NavLinks>
      )}
    </Nav>
  );
};

export default Navbar;

// ---------- Styled Components ----------

const Nav = styled.nav`
  height: 64px;
  padding: 0 2rem;
  background-color: #0f172a;
  color: white;
  display: flex;
  align-items: center;
  justify-content: space-between;
  border-bottom: 1px solid #1e293b;
`;

const Logo = styled(Link)`
  font-size: 1.5rem;
  font-weight: bold;
  text-decoration: none;
  color: white;
`;

const NavLinks = styled.div`
  display: flex;
  gap: 1rem;

  @media (max-width: 600px) {
    display: none;
  }
`;

const StyledLink = styled(Link)<{ $active?: boolean }>`
  color: ${({ $active }) => ($active ? "#38bdf8" : "white")};
  font-weight: 500;
  text-decoration: none;
  border-bottom: ${({ $active }) => ($active ? "2px solid #38bdf8" : "none")};
  padding-bottom: 2px;

  &:hover {
    color: #38bdf8;
  }
`;

const StyledNavButton = styled.button`
  color: white;
  background: none;
  border: none;
  font-weight: 500;
  font-size: 1rem;
  cursor: pointer;

  &:hover {
    color: #38bdf8;
  }
`;

const ProfileSection = styled.div`
  display: flex;
  align-items: center;
  gap: 0.75rem;
`;

const Avatar = styled.img`
  width: 32px;
  height: 32px;
  border-radius: 50%;
  object-fit: cover;
`;

const UserName = styled.span`
  font-weight: 500;
`;

const LogoutButton = styled.button`
  padding: 6px 12px;
  background-color: #1e293b;
  border: none;
  border-radius: 4px;
  color: white;
  font-size: 0.85rem;
  cursor: pointer;

  &:hover {
    background-color: #334155;
  }
`;
