import React from 'react';
import styled from 'styled-components';

const Header = styled.div`
  display: flex;
  flex-direction: column;
  gap: 4px;
`;

const Heading = styled.h1`
  font-size: 2rem;
  color: #ffffff;
`;

const SubHeading = styled.p`
  font-size: 1rem;
  color: #94a3b8;
`;

const GreetingHeader: React.FC = () => {
  const today = new Date().toLocaleDateString();

  return (
    <Header>
      <Heading>Welcome, Sanjay 👋</Heading>
      <SubHeading>{today}</SubHeading>
    </Header>
  );
};

export default GreetingHeader;
