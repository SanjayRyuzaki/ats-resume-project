import React from 'react';
import styled from 'styled-components';
import { motion } from 'framer-motion';

interface ResumeCardProps {
  title: string;
  date: string;
  score: number;
}

const Card = styled(motion.div)`
  background-color: #1e293b;
  border-radius: 12px;
  padding: 1.5rem;
  box-shadow: 0 8px 20px rgba(0, 0, 0, 0.3);
  display: flex;
  flex-direction: column;
  gap: 1rem;
`;

const Title = styled.h3`
  font-size: 1.1rem;
  font-weight: 600;
  color: white;
`;

const DateText = styled.span`
  font-size: 0.9rem;
  color: #94a3b8;
`;

const ProgressBar = styled.div`
  height: 12px;
  border-radius: 8px;
  overflow: hidden;
  background-color: #334155;
`;

const Progress = styled.div<{ $score: number }>`
  height: 100%;
  width: ${({ $score }) => `${$score}%`};
  background-color: ${({ $score }) =>
    $score >= 80 ? '#22c55e' :
    $score >= 60 ? '#facc15' :
    '#f43f5e'};
`;

const Score = styled.div`
  font-size: 1rem;
  font-weight: 500;
  color: #e2e8f0;
`;

const Button = styled.button`
  margin-top: auto;
  background-color: transparent;
  border: 1px solid #94a3b8;
  color: #e2e8f0;
  padding: 0.5rem 1rem;
  font-size: 0.9rem;
  border-radius: 6px;
  cursor: pointer;

  &:hover {
    background-color: #334155;
  }
`;

const ResumeCard: React.FC<ResumeCardProps> = ({ title, date, score }) => {
  return (
    <Card
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
    >
      <Title>{title}</Title>
      <DateText>Uploaded: {date}</DateText>
      <Score>ATS Score: {score}%</Score>
      <ProgressBar>
        <Progress $score={score} />
      </ProgressBar>
      <Button>View Details</Button>
    </Card>
  );
};

export default ResumeCard;
