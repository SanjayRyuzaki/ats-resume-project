import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import { CloudArrowUpIcon } from '@heroicons/react/24/solid';
import { motion } from 'framer-motion';
import Navbar from '../components/Navbar/Navbar'; // ✅ Adjust the path if needed

const Upload = () => {
  const [resume, setResume] = useState<File | null>(null);
  const [jobDesc, setJobDesc] = useState<File | null>(null);
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!resume || !jobDesc) {
      alert('Please upload both files.');
      return;
    }

    const formData = new FormData();
    formData.append('resume', resume);
    formData.append('job', jobDesc);

    try {
      setLoading(true);
      const token = localStorage.getItem('token');
      const response = await axios.post('http://localhost:5000/api/score', formData, {
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      });

      const score = response.data.score;
      localStorage.setItem('score', score.toString());
      navigate('/score');
    } catch (err) {
      alert('Error uploading files. Please try again.');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <Navbar />

      <div className="min-h-screen bg-gradient-to-br from-indigo-200 via-purple-300 to-pink-200 flex items-center justify-center px-4">
        <motion.div
          initial={{ opacity: 0, y: 60 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="backdrop-blur-md bg-white/30 border border-white/40 rounded-xl shadow-xl p-8 w-full max-w-xl"
        >
          <div className="text-center mb-6">
            <CloudArrowUpIcon className="h-12 w-12 text-indigo-600 mx-auto" />
            <h2 className="text-3xl font-bold text-gray-800 mt-2">Upload Your Resume</h2>
            <p className="text-gray-600 mt-1">Match your resume to the job description</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Resume File Input */}
            <label className="flex items-center justify-between gap-3 px-4 py-3 bg-white/50 hover:bg-white/70 transition border border-gray-300 rounded-lg cursor-pointer">
              <div className="text-left flex-1">
                <span className="block text-gray-700 font-medium">Resume</span>
                <span className="text-sm text-gray-600">
                  {resume ? resume.name : "No file selected"}
                </span>
              </div>
              <input
                type="file"
                accept=".pdf,.doc,.docx"
                onChange={(e) => setResume(e.target.files?.[0] || null)}
                className="hidden"
              />
              <CloudArrowUpIcon className="h-5 w-5 text-indigo-500" />
            </label>

            {/* Job Description File Input */}
            <label className="flex items-center justify-between gap-3 px-4 py-3 bg-white/50 hover:bg-white/70 transition border border-gray-300 rounded-lg cursor-pointer">
              <div className="text-left flex-1">
                <span className="block text-gray-700 font-medium">Job Description</span>
                <span className="text-sm text-gray-600">
                  {jobDesc ? jobDesc.name : "No file selected"}
                </span>
              </div>
              <input
                type="file"
                accept=".txt,.pdf"
                onChange={(e) => setJobDesc(e.target.files?.[0] || null)}
                className="hidden"
              />
              <CloudArrowUpIcon className="h-5 w-5 text-indigo-500" />
            </label>

            <button
              type="submit"
              disabled={loading}
              className="w-full flex items-center justify-center gap-2 bg-gradient-to-r from-indigo-500 to-purple-500 text-white font-semibold py-3 px-6 rounded-lg shadow-md hover:from-indigo-600 hover:to-purple-600 transition"
            >
              {loading ? (
                <svg className="animate-spin h-5 w-5 text-white" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z" />
                </svg>
              ) : (
                'Submit'
              )}
            </button>
          </form>
        </motion.div>
      </div>
    </>
  );
};

export default Upload;
