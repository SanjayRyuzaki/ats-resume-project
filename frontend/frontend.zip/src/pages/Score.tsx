import { useEffect, useState } from 'react';

export default function Score() {
  const [score, setScore] = useState<number | null>(null);

  useEffect(() => {
    const storedScore = localStorage.getItem('score');
    if (storedScore) {
      setScore(Number(storedScore));
    }
  }, []);

  return (
    <div style={{ textAlign: 'center', marginTop: '50px' }}>
      {score !== null ? (
        <h1>Your ATS Score: {score}%</h1>
      ) : (
        <p>Loading score...</p>
      )}
    </div>
  );
}
