import styled, { keyframes } from "styled-components";

export const LoginContainer = styled.div`
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  background: radial-gradient(ellipse at top left, #c2dfff, #e0d3ff, #fce2ff);
  overflow: hidden;
  font-family: 'DM Sans', 'Inter', sans-serif;
  position: relative;
`;

export const LoginCard = styled.div`
  backdrop-filter: blur(20px);
  background: rgba(255, 255, 255, 0.15);
  border: 1px solid rgba(255, 255, 255, 0.25);
  box-shadow: 0 8px 40px rgba(0, 0, 0, 0.15);
  padding: 3rem 2rem;
  border-radius: 16px;
  max-width: 400px;
  width: 100%;
  color: #111;
`;

export const Heading = styled.h2`
  text-align: center;
  font-size: 2rem;
  font-weight: 700;
  color: #1a1a1a;
  margin-bottom: 2rem;
`;

export const AnimatedForm = styled.form`
  display: flex;
  flex-direction: column;
  gap: 1.5rem;
`;

export const InputWrapper = styled.div`
  position: relative;
  width: 100%;
`;

export const StyledInput = styled.input`
  width: 100%;
  padding: 1rem 1rem 1rem 3rem;
  border: 1px solid #ccc;
  background: rgba(255, 255, 255, 0.5);
  border-radius: 10px;
  outline: none;
  font-size: 1rem;
  transition: border-color 0.3s, background 0.3s;

  &:focus {
    border-color: #7f56d9;
    background: rgba(255, 255, 255, 0.9);
  }

  &:focus ~ label,
  &:not(:placeholder-shown) ~ label {
    top: -10px;
    left: 2.5rem;
    font-size: 0.75rem;
    color: #7f56d9;
  }
`;

export const StyledLabel = styled.label`
  position: absolute;
  top: 50%;
  left: 3rem;
  transform: translateY(-50%);
  color: #777;
  font-size: 1rem;
  transition: 0.2s ease;
  pointer-events: none;
`;

export const IconWrapper = styled.div`
  position: absolute;
  top: 50%;
  left: 0.9rem;
  transform: translateY(-50%);
  font-size: 1.2rem;
  color: #999;
`;

export const SubmitButton = styled.button`
  background: linear-gradient(to right, #7f56d9, #5e60ce);
  color: white;
  border: none;
  border-radius: 8px;
  padding: 0.9rem;
  font-size: 1rem;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.3s ease;

  &:hover {
    box-shadow: 0 0 10px rgba(94, 96, 206, 0.5);
    transform: translateY(-1px);
  }

  &:disabled {
    opacity: 0.7;
    cursor: not-allowed;
  }
`;

export const Divider = styled.div`
  text-align: center;
  margin: 1.5rem 0;
  font-size: 0.85rem;
  color: #666;
  position: relative;

  &:before,
  &:after {
    content: "";
    height: 1px;
    width: 40%;
    background: #ccc;
    position: absolute;
    top: 50%;
  }

  &:before {
    left: 0;
  }

  &:after {
    right: 0;
  }
`;

export const OAuthWrapper = styled.div`
  display: flex;
  justify-content: center;
`;

export const Spinner = styled.div`
  border: 3px solid rgba(255, 255, 255, 0.3);
  border-top: 3px solid #fff;
  border-radius: 50%;
  width: 18px;
  height: 18px;
  animation: spin 0.6s linear infinite;

  @keyframes spin {
    to {
      transform: rotate(360deg);
    }
  }
`;

export const DarkToggle = styled.div``; // optional: placeholder for toggle logic
