// src/pages/Dashboard.tsx
import { useEffect, useState } from "react";
import { Resume } from "../types/resume";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../hooks/useAuth";
import Navbar from "../components/Navbar/Navbar";

export default function Dashboard() {
  const [resumes, setResumes] = useState<Resume[]>([]);
  const [loading, setLoading] = useState(true);
  const { user } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    const fetchHistory = async () => {
      try {
        const token = localStorage.getItem("token");
        const res = await fetch("http://localhost:5000/api/checks", {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });

        if (!res.ok) throw new Error("Failed to fetch history");

        const data = await res.json();
        setResumes(data.history || []);
      } catch (err) {
        console.error("Error fetching history:", err);
      } finally {
        setLoading(false);
      }
    };

    fetchHistory();
  }, []);

  return (
    <>
      <Navbar />
      <div className="min-h-screen px-4 py-10 bg-gradient-to-br from-purple-100 via-indigo-100 to-pink-100">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-4xl font-bold mb-4">Welcome, {user?.name || "User"} 👋</h1>
          <p className="text-lg text-gray-600 mb-8">Your ATS Score History</p>

          <button
            onClick={() => navigate("/upload")}
            className="mb-8 px-6 py-3 bg-indigo-600 text-white rounded-lg shadow hover:bg-indigo-700 transition"
          >
            Upload New Resume
          </button>

          {loading ? (
            <p>Loading your history...</p>
          ) : resumes.length === 0 ? (
            <p className="text-gray-600">No resumes uploaded yet.</p>
          ) : (
            <div className="space-y-4">
              {resumes.map((resume) => (
                <div
                  key={resume.id}
                  className="flex justify-between items-center p-4 bg-white rounded shadow"
                >
                  <div>
                    <h3 className="text-lg font-semibold">{resume.title}</h3>
                    <p className="text-sm text-gray-500">
                      Uploaded: {new Date(resume.upload_date).toLocaleString()}
                    </p>
                  </div>
                  <span className="text-xl font-bold text-indigo-600">
                    {resume.score}%
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </>
  );
}
